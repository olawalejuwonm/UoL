// /*
//   ==============================================================================

//     AnalyserDisplay.h
//     Created: 11 Sep 2023 7:34:33pm
//     Author:  USER

//   ==============================================================================
// */

// #pragma once

// #include <JuceHeader.h>

// //==============================================================================
// /*
//  */
// class AnalyserDisplay : public juce::Component
// {
// public:
//   AnalyserDisplay();
//   ~AnalyserDisplay() override;

//   void paint(juce::Graphics &) override;
//   void resized() override;

//   void drawNextFrameOfSpectrum();

//   void drawFrame(juce::Graphics &g);

// private:
//   JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AnalyserDisplay)
// };
