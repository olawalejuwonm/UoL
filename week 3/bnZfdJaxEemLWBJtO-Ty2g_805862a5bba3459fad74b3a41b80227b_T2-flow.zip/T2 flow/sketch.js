function setup()
{
	createCanvas(600, 600);
}

function draw()
{
	fill(255, 0, 0);
	rect(100, 100, 200, 200);

	fill(0, 0, 255);
	rect(200, 200, 200, 200);

}