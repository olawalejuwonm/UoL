function setup()
{
	//create your canvas here
}

function draw()
{
	//do your drawing here
}