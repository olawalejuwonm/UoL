You are not required to do any work inside this folder for topic5.
You are only required to use the Terminal to complete this section.