

function setup() 
{
    createCanvas(512,512);

}

function draw()
{
    background(255);

}


