//This file contains all html elements that are used dynamically in the home page.
//They are here to make it easier to change the html elements in one place.
//and also to avoid having to change the html in multiple places.
//They are reffered to as components, following the DRY(Don't Repeat Yourself) principle.